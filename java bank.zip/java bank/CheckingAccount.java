/*

This account inherits from the Account class
It contains methods such as balance checking, crediting and debiting into the check account by a customer
*/
public class CheckingAccount extends Account {

   double feeCharged;

   /*
   Function to check the balance but then subtracts a fee for balance chacking
   */
   public CheckingAccount(int initialBalance, double feeCharged) {
       super(initialBalance);
       // TODO Auto-generated constructor stub
       this.feeCharged = feeCharged;

   }

   /*
   Function to perform credit operations such as adding the amount credited and then subtracting fee charged from initial balance
   */
   public void credit(int amount) {
       if (amount > 0) {
           this.initialBalance += (amount - feeCharged);

       }

   }

   /*
   Function to perform debit operations such as deducting amount debited and fee charged from initial balance
   */
   public void debit(int amount) {
       if (this.initialBalance - amount - feeCharged > 500) {
           this.initialBalance -= (amount - feeCharged);
       }

   }

   /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#toString()
   */
   @Override
   public String toString() {
       return "CheckingAccount [feeCharged=" + feeCharged
               + ", initialBalance=" + initialBalance + "]";
   }

}
