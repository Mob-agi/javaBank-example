/*
This is the driver class that creates objects for each class so as to test each of their individual methods
We calculate interest by invoking calculateInterest() method
then we add interest to the savings account object
We  the create an array of account references to saving and checking acounts objects
After proccessing the account we then print the updated balance gotten through getBalance method from the base class
*/
public class TestAccount {

   /**
   * @param args
   */
   public static void main(String[] args) {

       try {
           SavingsAccount savingsAccount = new SavingsAccount(5000, 7);

           savingsAccount.credit(savingsAccount.calculateInterest());

           System.out.println(savingsAccount);
			
			//Here we create an array of account references to saving and checking objects
           Account account[] = new Account[2];

           account[0] = new SavingsAccount(4500, 9);
           account[1] = new CheckingAccount(12000, 16);

           //Determining each type of the account
           //for savings account we calculate the interest amount
           for (int i = 0; i < account.length; i++) {
               if (account[i] instanceof SavingsAccount) {
                   SavingsAccount acc = (SavingsAccount) account[i];
                   acc.credit(acc.calculateInterest());
                   System.out.println(acc);

               } else {
                   CheckingAccount acc = (CheckingAccount) account[i];

                   acc.credit(2500);
                   System.out.println(acc);

               }
           }
       } catch (Exception e) {
           //handle exception
       }
   }
}
