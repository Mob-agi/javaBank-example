
/*

This account inherits from the Account class
It contains methods such as balance checking, calculation interest that a customer earns
*/
public class SavingsAccount extends Account {

   double interestRate;

   
   public SavingsAccount(int initialBalance, double interestRate) {
       super(initialBalance);
       this.interestRate = interestRate;
       // Auto-generated constructor stub
   }

	//This method performs interest calculation
   public double calculateInterest() {

       return (getInitialBalance() * interestRate) / 100;

   }

   @Override
   public String toString() {
       return "SavingsAccount [interestRate=" + interestRate
               + ", initialBalance=" + initialBalance + "]";
   }

}
