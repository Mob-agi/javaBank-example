/*
This is the constructor class from which teh savings and checking classes inherits from
It contains getters and setters for crediting, debiting and checking of initail balance by customers
*/
public class Account {
   double initialBalance;

   public Account() {
       //Auto-generated constructor stub
       initialBalance = 500;
   }

   /*
   Method to set initial balance
   */
   public Account(double initialBalance) {
       setInitialBalance(initialBalance);
   }

   /*
   Method that returns the initial balance in a customer's account
   */
   public double getInitialBalance() {
       return initialBalance;
   }

   /*
   Setting of initial balance
   */
   public void setInitialBalance(double initialBalance) {
       if (initialBalance >= 500) {
           this.initialBalance = initialBalance;
       }

   }

   /*
   This method credits into a customer account. It adds the new amount to the initial balance in the account
   */
   public void credit(double amount) {
       if (amount > 0) {
           this.initialBalance += amount;
       }

   }

   /*
   This method does the debiting to a customers account
   */
   public void debit(double amount) {
       if (this.initialBalance - amount > 500) {
           this.initialBalance -= amount;
       }

   }

}
